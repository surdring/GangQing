import { GoogleGenAI, Content, Part } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";
import { Message, EvidenceItem } from "../types";

// Helper to simulate evidence generation based on response context
// In a real app, this would come from the RAG pipeline or function calls
const generateMockEvidence = (query: string): EvidenceItem => {
  const isCost = query.toLowerCase().includes('cost') || query.toLowerCase().includes('price');
  const isMaintenance = query.toLowerCase().includes('fix') || query.toLowerCase().includes('broken') || query.toLowerCase().includes('sound');

  if (isCost) {
    return {
      id: `ev-${Date.now()}`,
      title: 'Cost Analysis Source',
      source: 'SAP-CO (Controlling Module)',
      timestamp: new Date().toISOString(),
      confidence: 0.98,
      description: 'Data aggregated from procurement orders PO-2023-889 to PO-2023-912. Allocation logic v2.1 applied.',
      rawJson: JSON.stringify({ material: "Coke", price_index: 115, variance: "+15%" }, null, 2)
    };
  } else if (isMaintenance) {
    return {
      id: `ev-${Date.now()}`,
      title: 'Fault Diagnosis History',
      source: 'EAM-Maximo / Knowledge Graph',
      timestamp: new Date().toISOString(),
      confidence: 0.85,
      description: 'Matched with 12 historical cases of "Inner Race Fatigue Spalling".',
      rawJson: JSON.stringify({ part: "Bearing SKF-22312", stock: 2, location: "Warehouse A-12" }, null, 2)
    };
  } else {
    return {
      id: `ev-${Date.now()}`,
      title: 'Production Log',
      source: 'MES-BaoSight',
      timestamp: new Date().toISOString(),
      confidence: 1.0,
      description: 'Real-time telemetry from DCS Layer 2.',
    };
  }
};

export const sendMessageToGemini = async (
  history: Message[],
  currentInput: string,
  imageBase64?: string
): Promise<{ text: string; evidence: EvidenceItem | null; dataViz?: any }> => {
  
  if (!process.env.API_KEY) {
    console.error("API Key missing");
    return { 
      text: "Error: API Key is missing. Please check configuration.", 
      evidence: null 
    };
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Convert internal Message format to Gemini Content format
  // We filter out system messages from the history passed to generateContent 
  // because we use systemInstruction in the config.
  let contents: Content[] = history
    .filter(m => m.role !== 'system')
    .map(m => ({
      role: m.role,
      parts: [{ text: m.content }] as Part[]
    }));

  // Construct current user message parts
  const currentParts: Part[] = [{ text: currentInput }];
  if (imageBase64) {
    currentParts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: imageBase64
      }
    });
  }

  // Add current message to contents
  // Note: generateContent accepts a single content or array. 
  // Here we are effectively building a chat history manually.
  // Ideally, use chat.sendMessage, but stateless request allows easier history manipulation for this demo.
  contents.push({ role: 'user', parts: currentParts });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.2, // Low temp for industrial accuracy
      }
    });

    const text = response.text || "System: No response generated.";
    
    // Simulate Data Visualization extraction (Regex or heuristic)
    let dataViz = undefined;
    if (text.includes("cost") && text.includes("chart")) {
        dataViz = {
            type: 'bar',
            title: 'Cost Breakdown (USD/Ton)',
            keys: ['cost'],
            data: [
                { name: 'Raw Material', cost: 450 },
                { name: 'Energy', cost: 120 },
                { name: 'Labor', cost: 80 },
                { name: 'Depreciation', cost: 40 },
            ]
        };
    } else if (text.includes("trend") || text.includes("temperature")) {
         dataViz = {
            type: 'line',
            title: 'Furnace Temperature Trend (Last 12h)',
            keys: ['temp', 'limit'],
            data: [
                { name: '00:00', temp: 1420, limit: 1500 },
                { name: '04:00', temp: 1450, limit: 1500 },
                { name: '08:00', temp: 1480, limit: 1500 },
                { name: '12:00', temp: 1430, limit: 1500 },
            ]
        };
    }

    return {
      text,
      evidence: generateMockEvidence(currentInput),
      dataViz
    };

  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      text: "System Error: Unable to connect to the cognitive engine. " + (error instanceof Error ? error.message : String(error)),
      evidence: null
    };
  }
};
