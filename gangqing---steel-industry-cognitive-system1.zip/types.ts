export type Role = 'user' | 'model' | 'system';

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: Date;
  // Optional structured data for the UI
  dataVisualization?: {
    type: 'bar' | 'line' | 'pie' | 'composed';
    title: string;
    data: any[];
    keys: string[];
  };
  evidenceId?: string; // Links to evidence panel
}

export interface EvidenceItem {
  id: string;
  title: string;
  source: string; // e.g., "SAP-MM", "MES-Prod"
  timestamp: string;
  confidence: number;
  description: string;
  rawJson?: string;
}

export interface Metric {
  id: string;
  label: string;
  value: string | number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  status: 'normal' | 'warning' | 'critical';
  timestamp: string;
}

export interface Alert {
  id: string;
  title: string;
  severity: 'info' | 'warning' | 'critical';
  timestamp: string;
  message: string;
}

export interface UserProfile {
  name: string;
  role: 'Manager' | 'Scheduler' | 'Maintenance' | 'Finance';
  avatarUrl: string;
}
