import React from 'react';
import { Metric, Alert } from '../types';
import MetricCard from './MetricCard';
import { Bell, Activity } from 'lucide-react';

interface StreamPanelProps {
  metrics: Metric[];
  alerts: Alert[];
}

const StreamPanel: React.FC<StreamPanelProps> = ({ metrics, alerts }) => {
  return (
    <div className="h-full overflow-y-auto bg-steel-900 border-r border-steel-700 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-steel-700 bg-steel-900 sticky top-0 z-10">
        <h1 className="text-xl font-bold text-white tracking-tight flex items-center">
            <span className="w-2 h-6 bg-industrial-orange mr-2 rounded-sm"></span>
            GangQing
        </h1>
        <p className="text-xs text-steel-400 mt-1 uppercase tracking-widest">Cognitive Core v1.0</p>
      </div>

      {/* Alerts Section */}
      <div className="p-4">
        <div className="flex items-center text-steel-300 mb-3 text-xs font-bold uppercase tracking-wider">
            <Bell className="w-4 h-4 mr-2" />
            Live Alerts ({alerts.length})
        </div>
        <div className="space-y-2">
            {alerts.map(alert => (
                <div key={alert.id} className={`p-3 rounded text-xs border ${alert.severity === 'critical' ? 'bg-red-900/10 border-red-800 text-red-200' : 'bg-yellow-900/10 border-yellow-800 text-yellow-200'}`}>
                    <div className="font-bold mb-1 flex justify-between">
                        <span>{alert.title}</span>
                        <span className="opacity-70">{alert.timestamp}</span>
                    </div>
                    <div>{alert.message}</div>
                </div>
            ))}
        </div>
      </div>

      <div className="border-t border-steel-700 my-2 mx-4"></div>

      {/* Metrics Section */}
      <div className="p-4 flex-1">
        <div className="flex items-center text-steel-300 mb-3 text-xs font-bold uppercase tracking-wider">
            <Activity className="w-4 h-4 mr-2" />
            Key Indicators
        </div>
        {metrics.map(metric => (
            <MetricCard key={metric.id} metric={metric} />
        ))}
      </div>
    </div>
  );
};

export default StreamPanel;
