import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';
import { Send, Mic, Image as ImageIcon, RotateCcw, BarChart2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts';

interface ChatInterfaceProps {
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (text: string, image?: File) => void;
  onViewEvidence: (evidenceId: string) => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isLoading, onSendMessage, onViewEvidence }) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = () => {
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onSendMessage(inputText || "Analyzing attached image...", e.target.files[0]);
      setInputText('');
    }
  };

  const renderChart = (viz: NonNullable<Message['dataVisualization']>) => {
    if (viz.type === 'bar') {
        return (
            <div className="w-full h-64 mt-4 bg-steel-900/50 rounded p-2 border border-steel-700">
                <div className="text-xs text-center text-steel-400 mb-2 font-mono">{viz.title}</div>
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={viz.data}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                        <YAxis stroke="#94a3b8" fontSize={12} />
                        <RechartsTooltip 
                            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9' }}
                            itemStyle={{ color: '#cbd5e1' }}
                        />
                        <Legend />
                        <Bar dataKey={viz.keys[0]} fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        );
    }
    if (viz.type === 'line') {
        return (
            <div className="w-full h-64 mt-4 bg-steel-900/50 rounded p-2 border border-steel-700">
                <div className="text-xs text-center text-steel-400 mb-2 font-mono">{viz.title}</div>
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={viz.data}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                        <YAxis stroke="#94a3b8" fontSize={12} domain={['auto', 'auto']} />
                        <RechartsTooltip 
                            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9' }}
                        />
                        <Legend />
                        {viz.keys.map((k, i) => (
                             <Line key={k} type="monotone" dataKey={k} stroke={i === 0 ? "#f97316" : "#22c55e"} strokeWidth={2} dot={false} />
                        ))}
                    </LineChart>
                </ResponsiveContainer>
            </div>
        );
    }
    return null;
  };

  return (
    <div className="flex flex-col h-full bg-steel-800 relative">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-steel-500 opacity-50">
                <div className="w-20 h-20 border-2 border-steel-600 rounded-full flex items-center justify-center mb-4">
                    <span className="text-3xl font-bold">GQ</span>
                </div>
                <p>GangQing Cognitive System Ready</p>
                <p className="text-sm mt-2">Try: "What is the cost per ton today?" or "Diagnose this bearing sound"</p>
            </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-4 shadow-sm ${
                msg.role === 'user'
                  ? 'bg-industrial-blue text-white rounded-br-none'
                  : 'bg-steel-700 text-steel-100 rounded-bl-none border border-steel-600'
              }`}
            >
              <div className="whitespace-pre-wrap text-sm leading-relaxed font-light">{msg.content}</div>
              
              {msg.dataVisualization && renderChart(msg.dataVisualization)}

              {msg.role === 'model' && msg.evidenceId && (
                 <div className="mt-3 pt-3 border-t border-steel-600/50 flex items-center justify-between">
                    <span className="text-[10px] text-steel-400 uppercase tracking-wider">Source: SAP/MES</span>
                    <button 
                        onClick={() => onViewEvidence(msg.evidenceId!)}
                        className="text-xs flex items-center text-industrial-blue hover:text-white transition-colors"
                    >
                        <BarChart2 className="w-3 h-3 mr-1" />
                        View Evidence Chain
                    </button>
                 </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start animate-pulse">
            <div className="bg-steel-700 text-steel-300 rounded-lg p-3 rounded-bl-none text-xs flex items-center">
                <RotateCcw className="w-3 h-3 mr-2 animate-spin" />
                Consulting Knowledge Graph...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-steel-900 border-t border-steel-700">
        <div className="relative flex items-end bg-steel-800 border border-steel-600 rounded-lg focus-within:ring-1 focus-within:ring-industrial-blue focus-within:border-industrial-blue transition-all">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Describe an anomaly, ask for a report, or upload a photo..."
            className="w-full bg-transparent text-white p-3 min-h-[50px] max-h-[150px] resize-none focus:outline-none text-sm"
            rows={1}
          />
          <div className="flex items-center pb-2 pr-2 space-x-2">
            <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*"
                onChange={handleFileSelect}
            />
            <button 
                onClick={() => fileInputRef.current?.click()}
                className="p-2 text-steel-400 hover:text-industrial-blue hover:bg-steel-700 rounded-full transition-colors"
                title="Upload Image/Audio"
            >
              <ImageIcon className="w-5 h-5" />
            </button>
            <button 
                className="p-2 text-steel-400 hover:text-industrial-orange hover:bg-steel-700 rounded-full transition-colors"
                title="Voice Input (Simulated)"
            >
              <Mic className="w-5 h-5" />
            </button>
            <button
              onClick={handleSend}
              disabled={!inputText.trim() && !isLoading}
              className={`p-2 rounded-full transition-colors ${
                inputText.trim() ? 'bg-industrial-blue text-white shadow-lg' : 'bg-steel-700 text-steel-500 cursor-not-allowed'
              }`}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="text-center mt-2">
             <span className="text-[10px] text-steel-500">
                AI can make mistakes. All critical actions require "Approval Workflow" per Safety Protocol 104-B.
             </span>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
