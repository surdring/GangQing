import React from 'react';
import { Metric } from '../types';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface MetricCardProps {
  metric: Metric;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric }) => {
  const statusColor = {
    normal: 'border-l-4 border-l-industrial-green bg-steel-800',
    warning: 'border-l-4 border-l-industrial-yellow bg-steel-800',
    critical: 'border-l-4 border-l-industrial-red bg-red-900/20',
  };

  const trendIcon = {
    up: <ArrowUpRight className="w-4 h-4 text-industrial-red" />,
    down: <ArrowDownRight className="w-4 h-4 text-industrial-green" />,
    stable: <Minus className="w-4 h-4 text-steel-400" />,
  };

  return (
    <div className={`p-3 mb-3 rounded shadow-md ${statusColor[metric.status]} transition-all hover:brightness-110 cursor-pointer`}>
      <div className="flex justify-between items-start">
        <span className="text-xs text-steel-400 uppercase tracking-wider">{metric.label}</span>
        {trendIcon[metric.trend]}
      </div>
      <div className="mt-1 flex items-baseline">
        <span className="text-xl font-bold font-mono text-white">{metric.value}</span>
        <span className="ml-1 text-xs text-steel-400">{metric.unit}</span>
      </div>
      <div className="mt-1 text-[10px] text-steel-500 text-right">
        Updated: {metric.timestamp}
      </div>
    </div>
  );
};

export default MetricCard;
