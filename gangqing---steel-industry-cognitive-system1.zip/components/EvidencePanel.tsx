import React from 'react';
import { EvidenceItem } from '../types';
import { ShieldCheck, Database, FileText, Link as LinkIcon, AlertTriangle } from 'lucide-react';

interface EvidencePanelProps {
  evidence: EvidenceItem | null;
}

const EvidencePanel: React.FC<EvidencePanelProps> = ({ evidence }) => {
  if (!evidence) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-steel-500 p-6 text-center border-l border-steel-700 bg-steel-900">
        <ShieldCheck className="w-16 h-16 mb-4 opacity-20" />
        <h3 className="text-lg font-semibold mb-2">Evidence & Audit</h3>
        <p className="text-sm">Select a data point or ask a question to view the data lineage, calculation logic, and source systems.</p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto border-l border-steel-700 bg-steel-900 p-4 animate-fadeIn">
      <div className="flex items-center space-x-2 mb-6 border-b border-steel-700 pb-4">
        <ShieldCheck className="w-6 h-6 text-industrial-blue" />
        <h2 className="text-lg font-bold text-white">Evidence Chain</h2>
      </div>

      <div className="space-y-6">
        {/* Source Card */}
        <div className="bg-steel-800 rounded p-4 border border-steel-600">
            <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-industrial-blue uppercase">Data Source</span>
                <Database className="w-4 h-4 text-steel-400" />
            </div>
            <div className="text-lg font-bold text-white mb-1">{evidence.source}</div>
            <div className="text-xs text-steel-400">Timestamp: {evidence.timestamp}</div>
        </div>

        {/* Confidence */}
        <div className="bg-steel-800 rounded p-4 border border-steel-600">
            <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-industrial-blue uppercase">Confidence</span>
                <div className={`text-xs font-bold px-2 py-0.5 rounded ${evidence.confidence > 0.9 ? 'bg-green-900 text-green-300' : 'bg-yellow-900 text-yellow-300'}`}>
                    {Math.round(evidence.confidence * 100)}%
                </div>
            </div>
            <div className="w-full bg-steel-700 h-2 rounded-full mt-2">
                <div 
                    className={`h-2 rounded-full ${evidence.confidence > 0.9 ? 'bg-industrial-green' : 'bg-industrial-yellow'}`} 
                    style={{ width: `${evidence.confidence * 100}%` }}
                ></div>
            </div>
        </div>

        {/* Description */}
        <div>
            <h3 className="text-sm font-semibold text-white mb-2 flex items-center">
                <FileText className="w-4 h-4 mr-2 text-steel-400" />
                Logic & Scope
            </h3>
            <p className="text-sm text-steel-300 leading-relaxed bg-steel-800/50 p-3 rounded">
                {evidence.description}
            </p>
        </div>

         {/* Raw Data Preview */}
        {evidence.rawJson && (
            <div>
                 <h3 className="text-sm font-semibold text-white mb-2 flex items-center">
                    <LinkIcon className="w-4 h-4 mr-2 text-steel-400" />
                    Raw Payload
                </h3>
                <pre className="text-[10px] bg-black p-3 rounded text-green-400 font-mono overflow-x-auto border border-steel-700">
                    {evidence.rawJson}
                </pre>
            </div>
        )}

        <div className="mt-8 pt-4 border-t border-steel-700">
             <div className="flex items-start space-x-3 p-3 bg-industrial-blue/10 rounded border border-industrial-blue/30">
                <AlertTriangle className="w-5 h-5 text-industrial-blue shrink-0" />
                <div className="text-xs text-industrial-blue">
                    <strong>Audit Log:</strong> This query has been recorded in the immutable ledger (Block #99212) for compliance.
                </div>
             </div>
        </div>
      </div>
    </div>
  );
};

export default EvidencePanel;
