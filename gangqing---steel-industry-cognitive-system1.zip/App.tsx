import React, { useState, useEffect } from 'react';
import { INITIAL_METRICS, INITIAL_ALERTS } from './constants';
import { Message, EvidenceItem, Metric, Alert } from './types';
import { sendMessageToGemini } from './services/geminiService';
import StreamPanel from './components/StreamPanel';
import ChatInterface from './components/ChatInterface';
import EvidencePanel from './components/EvidencePanel';

const App: React.FC = () => {
  const [metrics, setMetrics] = useState<Metric[]>(INITIAL_METRICS);
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeEvidence, setActiveEvidence] = useState<EvidenceItem | null>(null);

  // Simulate live data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(m => {
        if (m.unit === '°C') return { ...m, value: 1450 + Math.floor(Math.random() * 10 - 5) };
        if (m.unit === 'MW') return { ...m, value: Number((45 + Math.random()).toFixed(1)) };
        return m;
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSendMessage = async (text: string, imageFile?: File) => {
    // 1. Add User Message
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text + (imageFile ? ' [Image Attachment Uploaded]' : ''),
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);
    setActiveEvidence(null); // Reset side panel

    let imageBase64: string | undefined = undefined;
    if (imageFile) {
        const reader = new FileReader();
        reader.readAsDataURL(imageFile);
        await new Promise<void>((resolve) => {
            reader.onload = () => {
                const result = reader.result as string;
                // Remove prefix data:image/jpeg;base64,
                imageBase64 = result.split(',')[1];
                resolve();
            }
        });
    }

    // 2. Call Gemini
    const response = await sendMessageToGemini(messages, text, imageBase64);

    // 3. Add Model Message
    const modelMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      content: response.text,
      timestamp: new Date(),
      dataVisualization: response.dataViz,
      evidenceId: response.evidence ? response.evidence.id : undefined,
    };

    setMessages(prev => [...prev, modelMsg]);
    
    // 4. Update Context based on response (Mock logic for demo)
    if (response.evidence) {
        // Store evidence in a temporary map or just set it active if it's the latest
        // For simplicity in this demo, we can just set it active immediately if we wanted,
        // but the UX pattern is "Click to view".
        // We will store it in a way that the view handler can find it. 
        // For this simple demo, we will use a ref or just closure if the handler wasn't separate.
        // Actually, let's attach the evidence object to the message in state via a lookup map, 
        // or simpler: just keeping a single active evidence state is fine for the demo interaction.
        // To make "Click to View" work, we need to find the evidence later.
        // I'll cheat slightly for the demo and just set the *latest* evidence as the potential one to show
        // but only show it when clicked. To do this properly, I'd need a map.
        // Let's implement a simple cache in the component scope or use a Custom Event.
        // For React best practices, I'll store it in a Map in state if I had many, 
        // but here I'll just use a hidden state property or simple callback.
        
        // BETTER: When the user clicks "View Evidence", we pass the ID. 
        // I need to store the evidence objects.
        setEvidenceCache(prev => ({ ...prev, [response.evidence!.id]: response.evidence! }));
    }
    
    setIsLoading(false);
  };

  const [evidenceCache, setEvidenceCache] = useState<Record<string, EvidenceItem>>({});

  const handleViewEvidence = (evidenceId: string) => {
      const ev = evidenceCache[evidenceId];
      if (ev) setActiveEvidence(ev);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden font-sans text-steel-100">
      {/* Left: Stream Panel (20%) */}
      <div className="w-80 flex-shrink-0 hidden md:block">
        <StreamPanel metrics={metrics} alerts={alerts} />
      </div>

      {/* Center: Chat Interface (Flexible) */}
      <div className="flex-1 flex flex-col min-w-0">
        <ChatInterface 
            messages={messages} 
            isLoading={isLoading} 
            onSendMessage={handleSendMessage}
            onViewEvidence={handleViewEvidence}
        />
      </div>

      {/* Right: Evidence Panel (25% or Overlay on mobile) */}
      <div className="w-96 flex-shrink-0 hidden lg:block border-l border-steel-700 bg-steel-900">
        <EvidencePanel evidence={activeEvidence} />
      </div>
      
      {/* Mobile Overlay for Evidence (Simplified for demo) */}
      {activeEvidence && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/80 flex justify-end">
            <div className="w-80 h-full">
                 <button 
                    onClick={() => setActiveEvidence(null)}
                    className="absolute top-4 right-80 mr-2 text-white bg-steel-800 p-2 rounded"
                 >
                    Close
                 </button>
                 <EvidencePanel evidence={activeEvidence} />
            </div>
        </div>
      )}
    </div>
  );
};

export default App;
