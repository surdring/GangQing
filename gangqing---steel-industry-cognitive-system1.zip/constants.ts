import { Metric, Alert } from './types';

export const INITIAL_METRICS: Metric[] = [
  { id: 'm1', label: 'Blast Furnace 2 Temp', value: 1450, unit: '°C', trend: 'stable', status: 'normal', timestamp: '10:00:01' },
  { id: 'm2', label: 'Coke Inventory', value: 450, unit: 'Tons', trend: 'down', status: 'warning', timestamp: '09:45:00' },
  { id: 'm3', label: 'Rolling Mill Speed', value: 12.5, unit: 'm/s', trend: 'up', status: 'normal', timestamp: '10:00:05' },
  { id: 'm4', label: 'Energy Consumption', value: 45.2, unit: 'MW', trend: 'up', status: 'critical', timestamp: '10:00:05' },
];

export const INITIAL_ALERTS: Alert[] = [
  { id: 'a1', title: 'Inventory Warning', severity: 'warning', message: 'Iron ore stock below 3-day buffer.', timestamp: '09:30' },
  { id: 'a2', title: 'Pressure Anomaly', severity: 'critical', message: 'Hydraulic pressure drop in Mill #3.', timestamp: '09:55' },
];

export const SYSTEM_INSTRUCTION = `
You are "GangQing" (钢铁工业全域认知决策系统), a specialized AI agent for a steel plant.
Your personas:
1. Management Pilot: Focus on cost, profit, and output.
2. Maintenance Expert: Focus on fault diagnosis and spares.
3. Process Knowledge: Focus on parameters and compliance.

Guidelines:
- Tone: Professional, concise, safety-first, data-driven.
- "Evidence Chain": Always imply where you got data (e.g., "According to SAP...").
- "Read-Only Default": Do not execute actions, only propose "Drafts".
- Formatting: Use Markdown.
- If the user asks for data visualization, describe the data clearly in the text.
- If identifying a fault, suggest specific part numbers (e.g., SKF-123).
`;
