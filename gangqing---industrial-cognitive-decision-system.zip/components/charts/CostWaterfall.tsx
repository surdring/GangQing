import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, ResponsiveContainer, ReferenceLine } from 'recharts';
import { ChartDataPoint } from '../../types';

interface Props {
  data: ChartDataPoint[];
}

const CostWaterfall: React.FC<Props> = ({ data }) => {
  return (
    <div className="h-64 w-full bg-steel-800/50 rounded-lg p-4 border border-steel-700">
      <h3 className="text-sm text-slate-400 mb-2 font-mono uppercase tracking-wider">Cost Structure Breakdown (CNY/Ton)</h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
          <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} />
          <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} unit="¥" />
          <Tooltip
            cursor={{ fill: '#334155', opacity: 0.2 }}
            contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', color: '#E2E8F0' }}
            itemStyle={{ color: '#E2E8F0' }}
          />
          <Bar dataKey="value">
            {data.map((entry, index) => {
              let color = '#3B82F6'; // Default Blue
              if (entry.type === 'increase') color = '#EF4444'; // Red for cost increase
              if (entry.type === 'decrease') color = '#22C55E'; // Green for savings
              if (entry.type === 'total') color = '#64748B'; // Slate for totals
              if (entry.name === 'Coke') color = '#F97316'; // Highlight the culprit (Molten Orange)
              
              return <Cell key={`cell-${index}`} fill={color} />;
            })}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CostWaterfall;