import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Paperclip, ChevronDown, RotateCcw } from 'lucide-react';
import ChatMessage from './ChatMessage';
import ContextPanel from './ContextPanel';
import { Message, Evidence, Scenario } from '../types';
import { SCENARIOS, MOCK_WATERFALL_DATA, MOCK_SPECTRUM_DATA, SAMPLE_EVIDENCE } from '../constants';

interface Props {
  activeScenario: Scenario;
}

const ChatInterface: React.FC<Props> = ({ activeScenario }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [activeEvidence, setActiveEvidence] = useState<Evidence | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Reset chat when scenario changes
    setMessages([{
        id: 'init',
        role: 'assistant',
        content: `Hello. I am the GangQing ${activeScenario.role} Agent. \n${activeScenario.description}`,
        timestamp: Date.now()
    }]);
    setInput(activeScenario.initialMessage);
    setActiveEvidence(null);
  }, [activeScenario]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsProcessing(true);

    // Simulate Network/AI Latency
    setTimeout(() => {
        // Construct Response based on Scenario ID
        // In a real app, this would be the Gemini API call
        const responseMsg: Message = {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            timestamp: Date.now(),
            content: '',
        };

        if (activeScenario.id === 'cost-analysis') {
            responseMsg.content = `Yesterday's ton-steel cost for Blast Furnace #2 was **¥2,850**, exceeding the target by 4.2%.\n\nThe primary driver is a **15% surge in Coke prices**, while energy efficiency actually improved.`;
            responseMsg.evidence = [SAMPLE_EVIDENCE['sap-co']];
            responseMsg.chartData = MOCK_WATERFALL_DATA;
            responseMsg.chartType = 'waterfall';
        } else if (activeScenario.id === 'maintenance') {
            responseMsg.content = `I've analyzed the audio spectrum.\n\nDetected a dominant peak at **1200Hz** with increasing amplitude. This signature strongly suggests **Inner Race Defect** in the motor bearing (Confidence: 85%).\n\nSecondary possibility: Lubrication failure (Confidence: 40%).`;
            responseMsg.evidence = [SAMPLE_EVIDENCE['vib-sensor']];
            responseMsg.chartData = MOCK_SPECTRUM_DATA;
            responseMsg.chartType = 'spectrum';
            responseMsg.actions = [
                { label: 'Create Work Order', handlerId: 'wo', style: 'primary' },
                { label: 'Check Inventory', handlerId: 'inv', style: 'secondary' }
            ];
        } else {
            responseMsg.content = "Simulating parameter adjustment...\n\nReducing Coke Ratio by 2% increases risk of 'Cold Hearth' by 15% based on current ore quality. \n\n**Recommendation**: Maintain current ratio until Ore Batch #442 is depleted.";
            responseMsg.evidence = [];
            responseMsg.actions = [
                { label: 'Force Override (Requires Approval)', handlerId: 'override', style: 'danger' }
            ];
        }

        setMessages(prev => [...prev, responseMsg]);
        setIsProcessing(false);
    }, 1500);
  };

  return (
    <div className="flex flex-1 h-full overflow-hidden relative">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full bg-steel-900/50 relative">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {messages.map(msg => (
            <ChatMessage 
                key={msg.id} 
                message={msg} 
                onEvidenceClick={(ev) => setActiveEvidence(ev)} 
            />
          ))}
          {isProcessing && (
             <div className="p-6">
                <div className="flex items-center gap-2 text-molten-500 text-sm animate-pulse">
                    <span className="w-2 h-2 bg-molten-500 rounded-full"></span>
                    Thinking...
                </div>
             </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-steel-900 border-t border-steel-700">
          <div className="max-w-4xl mx-auto relative">
             {/* Suggestions / Quick Actions could go here */}
            <div className="flex items-end gap-2 bg-steel-800 rounded-xl border border-steel-700 p-2 focus-within:ring-2 focus-within:ring-molten-500/50 transition-all shadow-lg">
                <button className="p-3 text-slate-400 hover:text-white transition-colors">
                    <Paperclip size={20} />
                </button>
                <textarea 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                        }
                    }}
                    placeholder="Ask about production, maintenance, or costs..."
                    className="flex-1 bg-transparent border-none text-slate-200 placeholder-slate-500 focus:ring-0 resize-none py-3 max-h-32"
                    rows={1}
                />
                 <button className="p-3 text-slate-400 hover:text-white transition-colors">
                    <Mic size={20} />
                </button>
                <button 
                    onClick={handleSend}
                    disabled={!input.trim() || isProcessing}
                    className="p-3 bg-molten-600 hover:bg-molten-500 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-molten-500/20"
                >
                    <Send size={18} />
                </button>
            </div>
            <div className="text-center mt-2">
                 <p className="text-xs text-slate-500">GangQing Agent can make mistakes. Check evidence pills.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <ContextPanel evidence={activeEvidence} onClose={() => setActiveEvidence(null)} />
    </div>
  );
};

export default ChatInterface;