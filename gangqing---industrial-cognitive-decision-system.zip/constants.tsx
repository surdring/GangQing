import { ChartDataPoint, Evidence, Message, UserRole, Scenario } from './types';
import React from 'react';
import { Factory, Wrench, BarChart3, AlertTriangle } from 'lucide-react';

export const SCENARIOS: Scenario[] = [
  {
    id: 'cost-analysis',
    name: 'Cost Analysis (F1.1)',
    description: 'Analyze production costs and anomalies.',
    role: UserRole.MANAGER,
    initialMessage: "Show me yesterday's ton-steel cost for Blast Furnace #2."
  },
  {
    id: 'maintenance',
    name: 'Diagnostics (F2.1)',
    description: 'Audio/Visual equipment diagnosis.',
    role: UserRole.MAINTENANCE,
    initialMessage: "Analyze this recording from the rolling mill motor."
  },
  {
    id: 'simulation',
    name: 'Simulation (F4.5)',
    description: 'Run production simulation sandbox.',
    role: UserRole.SCHEDULER,
    initialMessage: "Simulate reducing coke ratio by 2%."
  }
];

export const MOCK_WATERFALL_DATA: ChartDataPoint[] = [
  { name: 'Base Cost', value: 2400, type: 'total' },
  { name: 'Iron Ore', value: 120, type: 'increase' },
  { name: 'Coke', value: 350, type: 'increase' },
  { name: 'Flux', value: 30, type: 'increase' },
  { name: 'Energy', value: -50, type: 'decrease' },
  { name: 'Total', value: 2850, type: 'total' },
];

export const MOCK_SPECTRUM_DATA: ChartDataPoint[] = Array.from({ length: 40 }, (_, i) => ({
  name: `${i * 50}Hz`,
  value: i === 24 ? 95 : 20 + Math.random() * 30, // Spike at 1200Hz
}));

export const SAMPLE_EVIDENCE: Record<string, Evidence> = {
  'sap-co': {
    id: 'ev-001',
    source: 'SAP-CO Module',
    timestamp: 'Today, 09:00:15',
    confidence: 'High',
    type: 'SAP',
    details: 'Procurement Order PO-99823 shows a 15% price hike in metallurgical coke due to supplier shortages.',
    dataPoints: [
      { label: 'Prev Price', value: '¥2,100/t' },
      { label: 'Curr Price', value: '¥2,415/t', change: 15 },
    ]
  },
  'vib-sensor': {
    id: 'ev-002',
    source: 'IoT Sensor VIB-204',
    timestamp: 'Real-time',
    confidence: 'Medium',
    type: 'IoT',
    details: 'Fourier transform analysis indicates dominant frequency at 1200Hz, characteristic of inner race defects.',
    dataPoints: [
      { label: 'Peak Freq', value: '1200Hz' },
      { label: 'Amplitude', value: '4.2mm/s', change: 120 },
    ]
  }
};